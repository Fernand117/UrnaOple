import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clausura',
  templateUrl: './clausura.component.html',
  styleUrls: ['./clausura.component.scss']
})
export class ClausuraComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
