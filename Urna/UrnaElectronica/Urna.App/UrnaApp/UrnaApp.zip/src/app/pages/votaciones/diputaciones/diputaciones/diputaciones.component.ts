import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diputaciones',
  templateUrl: './diputaciones.component.html',
  styleUrls: ['./diputaciones.component.scss']
})
export class DiputacionesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
