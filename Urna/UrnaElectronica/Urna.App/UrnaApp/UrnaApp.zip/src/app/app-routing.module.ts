import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BienvenidoComponent } from './pages/inicializacion/bienvenido/bienvenido/bienvenido.component';
import { VotacionesComponent } from './pages/votaciones/votaciones.component';

const routes: Routes = [
  { path: '', redirectTo: '/bienvenido', pathMatch: 'full' },
  { path: 'votaciones', component: VotacionesComponent },
  { path: 'bienvenido', component: BienvenidoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
